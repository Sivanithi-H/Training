package calculator;

public class Main {
    public static void main(String[] args) {
        calculator cal = new calculator();
        cal.welcomeMessage();
        cal.showOption();
        cal.setOperation();
        cal.getNumbers();
        cal.FunCall();
    }
}